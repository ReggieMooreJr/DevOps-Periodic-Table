﻿Imports System.ComponentModel
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Drawing
Imports System.Globalization


<DefaultProperty("Text"), ToolboxData("<{0}:DateInputControl runat=server></{0}:DateInputControl>")> _
Public Class DateInputControl
    Inherits WebControl
    Implements INamingContainer


    Private regexValue As String
    Private validationGroupValue As String
    Private requiredValue As Boolean = False
    Private formatterStringValue As String
    Private exceptionMessageValue As String = ""
    Private exceptionMessageFor2YearsValue As String = String.Empty
    Private dateRangeMessageValue As String = "Invalid Date Range"
    Private selectedDateValue As Date?
    Private txtDate As New TextBox
    Private cal As New WebControls.Calendar()
    Private DateRegexValidator As New RegularExpressionValidator()
    Private RequireFieldVld As New RequiredFieldValidator()
    Private btnOpenCal As New Button()
    Private hdnDefaultDateFormat As New HiddenField()
    Private textBoxStyleValue As String
    Private calendarStyleValue As String
    Private btnOpenCalStyleValue As String
    Private maxDateTodayCheckValue As Boolean = True
    Private maxDate2YearsCheckValue As Boolean = False
    Private _FieldID As Integer
    Private rqFldErrorMessageValue As String = ""
    Private regexErrorMessageValue As String = ""
    Private readOnlyTextBoxValue As Boolean = False

    Property ReadOnlyTextBox() As Boolean
        Get
            Dim s As String = CStr(ViewState("ReadOnlyTextBox"))
            If s Is Nothing Then
                Return False
            Else
                Return CBool(s)
            End If
        End Get
        Set(ByVal value As Boolean)
            If value = True Then
                txtDate.ReadOnly = True
            End If
            readOnlyTextBoxValue = value
            ViewState("ReadOnlyTextBox") = value
        End Set
    End Property

    Property ExceptionMessage() As String
        Get
            Dim s As String = CStr(ViewState("ExceptionMessage"))
            If s Is Nothing Then
                Return String.Empty
            Else
                Return s
            End If
        End Get
        Set(ByVal Value As String)
            exceptionMessageValue = Value
            ViewState("ExceptionMessage") = Value
        End Set
    End Property

    Property ExceptionMessageFor2Years() As String
        Get
            Dim s As String = CStr(ViewState("ExceptionMessageFor2Years"))
            If s Is Nothing Then
                Return String.Empty
            Else
                Return s
            End If
        End Get
        Set(ByVal Value As String)
            exceptionMessageFor2YearsValue = Value
            ViewState("ExceptionMessageFor2Years") = Value
        End Set
    End Property

    Property DateRangeMessage() As String
        Get
            Dim s As String = CStr(ViewState("DateRangeMessage"))
            If s Is Nothing Then
                Return String.Empty
            Else
                Return s
            End If
        End Get
        Set(ByVal Value As String)
            dateRangeMessageValue = Value
            ViewState("DateRangeMessage") = Value
        End Set
    End Property

    Public Property RequiredFieldErrorMessage() As String
        Get
            Dim s As String = CStr(ViewState("RequiredFieldErrorMessage"))
            If s Is Nothing Then
                Return String.Empty
            Else
                Return s
            End If
        End Get
        Set(ByVal value As String)
            rqFldErrorMessageValue = value
            ViewState("RequiredFieldErrorMessage") = value
            RequireFieldVld.ErrorMessage = value
        End Set
    End Property

    Public Overrides Property Width() As Unit
        Get
            Return MyBase.Width
        End Get
        Set(ByVal value As Unit)
            txtDate.Width = value
            MyBase.Width = value
        End Set
    End Property

    Public Overrides Property BackColor() As Color
        Get
            Return MyBase.BackColor
        End Get
        Set(ByVal value As Color)
            txtDate.BackColor = value
            MyBase.BackColor = value
        End Set
    End Property

    Public Property RegularExpressionErrorMessage() As String
        Get
            Dim s As String = CStr(ViewState("RegularExpressionErrorMessage"))
            If s Is Nothing Then
                Return String.Empty
            Else
                Return s
            End If
        End Get
        Set(ByVal value As String)
            regexErrorMessageValue = value
            ViewState("RegularExpressionErrorMessage") = value
            DateRegexValidator.ErrorMessage = value
        End Set
    End Property

    <Category("Behavior"), Description("FieldID attached to the textbox.")> _
    Property FieldID() As Integer
        Get
            Return _FieldID
        End Get
        Set(ByVal Value As Integer)
            _FieldID = Value
        End Set
    End Property

    Public Overrides Property BorderStyle() As BorderStyle
        Get
            Dim _
                s As BorderStyle = _
                    IIf(ViewState("BorderStyle") IsNot Nothing, CType((ViewState("BorderStyle")), BorderStyle), _
                         WebControls.BorderStyle.NotSet)
            Return s
            'Return Me.txtDate.BorderStyle
        End Get
        Set(ByVal value As BorderStyle)
            Me.txtDate.BorderStyle = value
            ViewState("BorderStyle") = value
        End Set
    End Property


    Public Property SelectedDate() As Date?
        Set(ByVal value As Date?)
            selectedDateValue = value
            'Text = GHTime.ConvertToDateFormat(value, FormatterString)
            If Not selectedDateValue Is Nothing Then
                txtDate.Text = GHTime.ConvertToDateFormat(value, FormatterString)
                ViewState("Text") = GHTime.ConvertToDateFormat(value, FormatterString)

            Else
                txtDate.Text = ""
                ViewState("Text") = ""
            End If
        End Set
        Get
            If txtDate.Text = "" Then
                Return Nothing
            End If

            Dim newFormat As String = formatterStringValue
            Dim culture As IFormatProvider = New CultureInfo("fr-FR", True)
            newFormat = newFormat.Replace("DD", "dd")
            newFormat = newFormat.Replace("YYYY", "yyyy")
            newFormat = newFormat.Replace("MI", "mm")
            newFormat = newFormat.Replace("SS", "ss")
            Dim dt As DateTime
            Try
                dt = DateTime.ParseExact(txtDate.Text, newFormat, culture)
                Dim d1 As Date = New Date(1753, 1, 1)
                Dim d2 As Date = New Date(9999, 12, 31)
                If dt < d1 OrElse dt > d2 Then
                    Throw New FormatException()
                End If
            Catch ex As FormatException
                Throw (New FormatException(DateRangeMessage))
            End Try
            If maxDate2YearsCheckValue = True Then
                If dt > Now.AddYears(2) Then
                    Throw New Exception(ExceptionMessageFor2Years)
                End If
            ElseIf maxDateTodayCheckValue = True Then
                If dt > Now Then
                    Throw New Exception(ExceptionMessage)
                End If
            End If
            Return dt
        End Get
    End Property

    Public Property Required() As Boolean
        Get
            Dim s As Boolean = IIf(ViewState("Required") IsNot Nothing, CBool(ViewState("Required")), False)
            Return s
            'Return requiredValue
        End Get
        Set(ByVal value As Boolean)
            requiredValue = value
            ViewState("Required") = value
            CreateChildControls()
        End Set
    End Property

    Public Property Regex() As String
        Get
            Dim s As String = CStr(ViewState("Regex"))
            If s Is Nothing Then
                Return String.Empty
            Else
                Return s
            End If
        End Get
        Set(ByVal value As String)
            regexValue = value
            ViewState("Regex") = value
            DateRegexValidator.ValidationExpression = value
        End Set
    End Property

    Public Property MaxDateTodayCheck() As Boolean
        Get
            Return maxDateTodayCheckValue
        End Get
        Set(ByVal value As Boolean)
            maxDateTodayCheckValue = value
        End Set
    End Property

    Public Property MaxDate2YearsCheck() As Boolean
        Get
            Return maxDate2YearsCheckValue
        End Get
        Set(ByVal value As Boolean)
            maxDate2YearsCheckValue = value
        End Set
    End Property

    Public Property FormatterString() As String
        Get
            Dim s As String = CStr(ViewState("FormatterString"))
            If s Is Nothing Then
                Return String.Empty
            Else
                Return s
            End If
        End Get
        Set(ByVal value As String)
            formatterStringValue = value
            ViewState("FormatterString") = value
        End Set
    End Property

    Public Sub New()
        MyBase.New()


    End Sub

    <Bindable(True), Category("Appearance"), DefaultValue(""), Localizable(True)> _
    Property Text() As String
        Get
            Dim s As String = CStr(ViewState("Text"))
            If s Is Nothing Then
                Return String.Empty
            Else
                Return s
            End If
        End Get

        Set(ByVal Value As String)
            If Value = "" Then
                txtDate.Text = Value
            Else
                txtDate.Text = GHTime.ConvertToDateFormat(Value, FormatterString)
            End If

            ViewState("Text") = Value
        End Set
    End Property

    Public Property ValidationGroup() As String
        Get
            Dim s As String = CStr(ViewState("ValidationGroup"))
            If s Is Nothing Then
                Return String.Empty
            Else
                Return s
            End If
            'Return validationGroupValue
        End Get
        Set(ByVal value As String)
            validationGroupValue = value
            ViewState("ValidationGroup") = value
        End Set
    End Property

    Public Property TextBoxStyleCSS() As String
        Get
            Dim s As String = CStr(ViewState("TextBoxStyleCSS"))
            If s Is Nothing Then
                Return String.Empty
            Else
                Return s
            End If
            'Return textBoxStyleValue
        End Get
        Set(ByVal value As String)
            textBoxStyleValue = value
            ViewState("TextBoxStyleCSS") = value
        End Set
    End Property

    Public Property CalendarStyleCSS() As String
        Get
            Return calendarStyleValue
        End Get
        Set(ByVal value As String)
            calendarStyleValue = value
        End Set
    End Property

    Public Property BtnOpenCalendarStyleCss() As String
        Get
            Return btnOpenCalStyleValue
        End Get
        Set(ByVal value As String)
            btnOpenCalStyleValue = value
        End Set
    End Property

    Protected Overrides Sub CreateChildControls()
        MyBase.CreateChildControls()

        Controls.Clear()

        DateRegexValidator.ControlToValidate = "txtDateBox"
        DateRegexValidator.ValidationExpression = Regex
        DateRegexValidator.Visible = True
        DateRegexValidator.ErrorMessage = "Please input date in format " + FormatterString
        DateRegexValidator.Text = ""
        DateRegexValidator.Display = ValidatorDisplay.Dynamic

        If Not RegularExpressionErrorMessage = "" Then
            DateRegexValidator.ErrorMessage = RegularExpressionErrorMessage
        End If


        RequireFieldVld.Text = ""
        RequireFieldVld.Display = ValidatorDisplay.Dynamic
        RequireFieldVld.ErrorMessage = "Select Date"

        If Not RequiredFieldErrorMessage = "" Then
            RequireFieldVld.ErrorMessage = RequiredFieldErrorMessage
        End If

        If Not ValidationGroup = "" Then
            DateRegexValidator.ValidationGroup = ValidationGroup
            RequireFieldVld.ValidationGroup = ValidationGroup
        End If

        txtDate.BorderStyle = Me.BorderStyle

        RequireFieldVld.ControlToValidate = "txtDateBox"


        btnOpenCal.Text = "..."
        btnOpenCal.Visible = True
        cal.Visible = False

        txtDate.ID = "txtDateBox"
        txtDate.MaxLength = 100

        txtDate.Width = New Unit("150px")
        If Me.Width <> Nothing Then
            txtDate.Width = Me.Width
        End If

        txtDate.CssClass = TextBoxStyleCSS
        btnOpenCal.CssClass = BtnOpenCalendarStyleCss
        cal.CssClass = CalendarStyleCSS


        Controls.Add(txtDate)
        Controls.Add(btnOpenCal)
        Controls.Add(DateRegexValidator)
        If Required = True Then
            Controls.Add(RequireFieldVld)
        End If
        Controls.Add(cal)

        
        If ReadOnlyTextBox = True Then
            txtDate.ReadOnly = True
        End If

        Controls.Add(hdnDefaultDateFormat)

        'If Not Page.IsPostBack And txtDate.Text = "" Then
        '    txtDate.Text = GHTime.ConvertToDateFormat(Now, FormatterString)
        'End If


        AddHandler btnOpenCal.Click, AddressOf Me.btnOpenCal_Click
        AddHandler cal.SelectionChanged, AddressOf Me.Calendar_SelectionChanged
        AddHandler cal.VisibleMonthChanged, AddressOf Me.Calender_VisibleMonthChanged


    End Sub

    Protected Sub Calender_VisibleMonthChanged(ByVal sender As Object, ByVal e As MonthChangedEventArgs) 'Handles cal.SelectionChanged

        cal.Visible = True
        Page.Validate()
    End Sub

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As EventArgs) Handles Me.Load
        DateRegexValidator.ValidationExpression = Regex
        btnOpenCal.Attributes.Add("onclick", "javascript:document.getElementById('" + Me.ID + "$txtDate').value='';")

    End Sub


    Protected Sub Calendar_SelectionChanged(ByVal sender As Object, ByVal e As EventArgs) 'Handles cal.SelectionChanged
        Me.Text = GHTime.ConvertToDateFormat(cal.SelectedDate, FormatterString)
        hdnDefaultDateFormat.Value = cal.SelectedDate.ToString
        cal.Visible = False

    End Sub


    Protected Sub btnOpenCal_Click(ByVal sender As Object, ByVal e As EventArgs) 'Handles btnOpenCal.Click
        cal.Visible = True
    End Sub
End Class
