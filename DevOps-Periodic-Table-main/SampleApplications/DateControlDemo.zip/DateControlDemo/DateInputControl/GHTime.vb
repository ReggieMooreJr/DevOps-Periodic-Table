﻿Imports Microsoft.VisualBasic
Imports System.Threading
Imports System.Globalization

Public Class GHTime

    Public Shared Function ConvertTimeZones(ByVal d As Date, ByVal sourceTimeZoneStandardName As String, ByVal targetTimeZoneStandardNAme As String) As Date

        Try
            Dim dt As New DateTime(d.Year, d.Month, d.Day, d.Hour, d.Minute, d.Second, DateTimeKind.Unspecified)
            Dim timeZone1 As TimeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById(sourceTimeZoneStandardName) '("India Standard Time")
            Dim timeZone2 As TimeZoneInfo = TimeZoneInfo.FindSystemTimeZoneById(targetTimeZoneStandardNAme) '("Central Standard Time")
            Return TimeZoneInfo.ConvertTime(dt, timeZone1, timeZone2).ToString

        Catch ex As Exception
            Throw New Exception("Error converting between timezones")
        End Try

    End Function

    Public Shared Function ConvertToDateFormat(ByVal d As Date, ByVal formatter As String) As String

        Dim currentCulture As String = Thread.CurrentThread.CurrentCulture.ToString
        Thread.CurrentThread.CurrentCulture = New CultureInfo("en-US")
        Thread.CurrentThread.CurrentUICulture = New CultureInfo("en-US")

        formatter = formatter.Replace("(24h)", "(24H)")


        If formatter.Contains("(24H)") Then
            formatter = formatter.Replace("HH", "HH24")
        Else
            formatter = formatter.Replace("HH", "HH12")
        End If

        formatter = formatter.Replace("(24H)", "")

        formatter = formatter.Replace("Month", d.ToString("MMMM"))
        formatter = formatter.Replace("Mon", d.ToString("MMMM").Substring(0, 3))
        formatter = formatter.Replace("DD", d.Day.ToString.PadLeft(2, "0"))
        formatter = formatter.Replace("MMM", d.Millisecond.ToString.PadLeft(3, "0"))
        formatter = formatter.Replace("MM", d.Month.ToString.PadLeft(2, "0"))
        formatter = formatter.Replace("YYYY", d.Year.ToString.PadLeft(4, "0"))
        formatter = formatter.Replace("YY", d.Year.ToString.PadLeft(2, "0").Substring(2))
        formatter = formatter.Replace("HH24", d.Hour.ToString.PadLeft(2, "0"))
        formatter = formatter.Replace("HH12", (d.Hour Mod 12).ToString.PadLeft(2, "0"))
        formatter = formatter.Replace("MI", d.Minute.ToString.PadLeft(2, "0"))
        formatter = formatter.Replace("SS", d.Second.ToString.PadLeft(2, "0"))

        Thread.CurrentThread.CurrentCulture = New CultureInfo(currentCulture)
        Thread.CurrentThread.CurrentUICulture = New CultureInfo(currentCulture)

        Return formatter

    End Function
End Class

