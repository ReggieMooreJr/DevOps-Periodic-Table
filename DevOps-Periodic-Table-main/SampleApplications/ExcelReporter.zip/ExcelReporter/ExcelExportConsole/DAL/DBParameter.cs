
#region References

using System;
using System.Data;
using System.Collections;
using System.Data.OleDb;
#endregion

#region namespace DATAMANAGER
namespace DATAMANAGER
{
	
	#region public class DBParameter
	/// <summary>
	/// The class creates the parameters for the stored procedure to be called.
	/// </summary>
	/// <remarks></remarks>	
	/// Revision History: 
	/// Author					| Ver			| Date				| Reason
    /// Sumit  			        | 5th May 2010 	| Intial Creation
	public class DBParameter
	{
		#region Data Members

		private ArrayList objDataParameter;

		#endregion

		#region Constructors

		public DBParameter()
		{
			objDataParameter = new ArrayList();		
		}

		#endregion

		#region Public Properties

		public ArrayList DBParameters
		{
			get
			{
				return objDataParameter;
			}
		}

		#endregion

		#region Public Functions

		#region public void AddParameter(string strParameterName, object objParameterValue)
		/// <summary>
		/// Used for adding the database parameters.
		/// </summary>
		/// <param name="strParameterName"></param>
		/// <param name="objParameterValue"></param>
		public void AddParameter(string strParameterName, object objParameterValue)
		{			
			OleDbParameter objParameter	= new OleDbParameter();
			objParameter.ParameterName	= strParameterName;
			if(objParameterValue == null )
				objParameter.Value			= DBNull.Value;
			else
				objParameter.Value			= objParameterValue;
			
			objParameter.Direction		= ParameterDirection.Input;
			objDataParameter.Add(objParameter);
		}
		#endregion

		#region public void AddParameter(string strParameterName, OleDbType dataType, object objParameterValue)
		/// <summary>
		/// Used for adding the database parameters.
		/// </summary>
		/// <param name="strParameterName"></param>
		/// <param name="dataType"></param>
		/// <param name="objParameterValue"></param>
		public void AddParameter(string strParameterName, OleDbType dataType, object objParameterValue)
		{			
			OleDbParameter objParameter	= new OleDbParameter();
			objParameter.ParameterName	= strParameterName;
			objParameter.OleDbType		= dataType;
			objParameter.Value			= objParameterValue;
			objParameter.Direction		= ParameterDirection.Input;
			objDataParameter.Add(objParameter);
		}
		#endregion
		
		#region public void AddParameter(string strParameterName, OleDbType dataType, object objParameterValue, int nSize)
		/// <summary>
		/// Used for adding the database parameters.
		/// </summary>
		/// <param name="strParameterName"></param>
		/// <param name="dataType"></param>
		/// <param name="objParameterValue"></param>
		/// <param name="nSize"></param>
		public void AddParameter(string strParameterName, OleDbType dataType, object objParameterValue, int nSize)
		{
			OleDbParameter objParameter	= new OleDbParameter();
			objParameter.ParameterName	= strParameterName;
			objParameter.OleDbType		= dataType;
			if(objParameterValue == null )
				objParameter.Value			= DBNull.Value;
			else
				objParameter.Value			= objParameterValue;
			
			objParameter.Direction		= ParameterDirection.Input;
			objParameter.Size			= nSize;
			objDataParameter.Add(objParameter);
		}
		#endregion

		#region public void AddParameter(string strParameterName, OleDbType dataType, object objParameterValue, ParameterDirection direction)		
		/// <summary>
		/// Used for adding the database parameters.
		/// </summary>
		/// <param name="strParameterName"></param>
		/// <param name="dataType"></param>
		/// <param name="objParameterValue"></param>
		/// <param name="direction"></param>
		public void AddParameter(string strParameterName, OleDbType dataType, object objParameterValue, ParameterDirection direction)
		{			
			OleDbParameter objParameter	= new OleDbParameter();
			objParameter.ParameterName	= strParameterName;
			objParameter.OleDbType		= dataType;
			if(objParameterValue == null )
				objParameter.Value			= DBNull.Value;
			else
				objParameter.Value			= objParameterValue;
			
			objParameter.Direction		= direction;
			objDataParameter.Add(objParameter);
		}
		#endregion
				
		#endregion
        
	}
	
	#endregion

}
#endregion