#region References
using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.Odbc;
using System.Data.OleDb;
using System.Data.OracleClient;
using System.Data.SqlClient;

#endregion

#region namespace DATAMANAGER

namespace UHG.CARE.DataManager
{

    #region public class DBAccess

    /// <summary>
    /// The Class provides the functionality for accessing the database
    /// </summary>
    /// <remarks></remarks>	
    /// Revision History: 
    /// Author					| Ver			| Date				| Reason
    /// Sumit  			        | 5th May 2010 	| Intial Creation
    /// Usage Example
    /*  DBAccess objDataAccessLayer = new DBAccess();
            DBParameter oDBParameter = new DBParameter();
            oDBParameter.AddParameter("@ID", SqlDbType.Int, ID, ParameterDirection.Input);
            objDataSet = objDataAccessLayer.executeSPReturnDS("PRC_D_CUSTOMER_DETAILS", oDBParameter.DBParameters);*/
    public class DBAccess
    {
        #region Data Region

        // DB config file path
        private static string _strDbConfigFilePath = null;
        // Connection string
        private static string _strConnectionString = null;
        // Connection object
        private OleDbConnection objConnection;
        private OdbcConnection odbcConn;
        private OracleConnection OracleConn;
        private SqlConnection SqlConn;

        #endregion

        #region Constructor

        /// <summary>
        /// Defaut constructor
        /// </summary>
        public DBAccess()
        {
            //Add Constructor code here
        }

        #endregion

        #region Public Properties

        /// <summary>
        /// Set the configuration File Path
        /// </summary>
        public static string DbConfigFilePath
        {
            set { _strDbConfigFilePath = value; }
        }

        #endregion

        #region Public Functions

        #region Open/Close datasource

        #region private OleDbConnection OpenDataSource()

        /// <summary>
        /// Used for getting the Connection Object
        /// </summary>
        /// <returns></returns>
        private OleDbConnection OpenDataSource(string ConnectionString)
        {
            //Test if OleDbConnection exists
            if (objConnection == null)
            {
                try
                {
                    objConnection = new OleDbConnection(ReadConnectionString(ConnectionString));
                    objConnection.Open();
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            else if (objConnection.State != ConnectionState.Open)
            {
                objConnection.ConnectionString = ReadConnectionString(ConnectionString);
                try
                {
                    objConnection.Open();
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            return objConnection;
        }

        /// <summary>
        /// Used for getting the Connection Object
        /// </summary>
        /// <returns></returns>
        private OdbcConnection OpenDataSourceOdbc(string ConnectionString)
        {
            //Test if OleDbConnection exists
            if (odbcConn == null)
            {
                try
                {
                    odbcConn = new OdbcConnection(ReadConnectionString(ConnectionString));
                    odbcConn.Open();
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            else if (odbcConn.State != ConnectionState.Open)
            {
                odbcConn.ConnectionString = ReadConnectionString(ConnectionString);
                try
                {
                    odbcConn.Open();
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            return odbcConn;
        }

        /// <summary>
        /// Used for getting the Connection Object
        /// </summary>
        /// <returns></returns>
        public OracleConnection OpenDataSourceOracle(string ConnectionString)
        {
            //Test if OleDbConnection exists
            if (OracleConn == null)
            {
                try
                {
                    OracleConn = new OracleConnection(ReadConnectionString(ConnectionString));
                    OracleConn.Open();
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            else if (OracleConn.State != ConnectionState.Open)
            {
                OracleConn.ConnectionString = ReadConnectionString(ConnectionString);
                try
                {
                    OracleConn.Open();
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            return OracleConn;
        }

        /// <summary>
        /// Used for getting the Connection Object
        /// </summary>
        /// <returns></returns>
        public SqlConnection OpenDataSourceSql(string ConnectionString)
        {
            //Test if OleDbConnection exists
            if (SqlConn == null)
            {
                try
                {
                    SqlConn = new SqlConnection(ReadConnectionString(ConnectionString));
                    SqlConn.Open();
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            else if (SqlConn.State != ConnectionState.Open)
            {
                SqlConn.ConnectionString = ReadConnectionString(ConnectionString);
                try
                {
                    SqlConn.Open();
                }
                catch (Exception e)
                {
                    throw e;
                }
            }
            return SqlConn;
        }

        #endregion

        #region private void CloseDataSources()

        /// <summary>
        /// Closes the connection object
        /// </summary>		 
        private void CloseDataSources()
        {
            try
            {
                if (OracleConn != null)
                {
                    if (OracleConn.State == ConnectionState.Open)
                    {
                        OracleConn.Close();
                    }
                    OracleConn = null;
                }
                if (SqlConn != null)
                {
                    if (SqlConn.State == ConnectionState.Open)
                    {
                        SqlConn.Close();
                    }
                    SqlConn = null;
                }
                if (odbcConn != null)
                {
                    if (odbcConn.State == ConnectionState.Open)
                    {
                        odbcConn.Close();
                    }
                    odbcConn = null;
                }
                if (objConnection != null)
                {
                    if (objConnection.State == ConnectionState.Open)
                    {
                        objConnection.Close();
                    }
                    objConnection = null;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        #endregion

        #endregion

        #region Fire SP with params, return Dataset

        #region public DataSet executeSPReturnDS(string strSpname)

        /// <summary>
        /// Executes the stored procedure and returns DataSet
        /// </summary>
        /// <param name="strSpname"></param>
        /// <returns></returns>
        public DataSet executeSPReturnDS(string strSpname, string ConnectionString)
        {
            try
            {
               return executeSPReturnDS(strSpname, null, ConnectionString);
            }
            catch (OleDbException se)
            {
                throw se;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        #endregion

        #region public DataSet executeSPReturnDS(string strSpname, ArrayList arrDataParameter)

        /// <summary>
        /// Executes the stored procedure and returns DataSet
        /// </summary>
        /// <param name="strSpname"></param>
        /// <param name="arrDataParameter"></param>
        /// <returns></returns>
        public DataSet executeSPReturnDS(string strSpname, ArrayList arrDataParameter, string ConnectionString)
        {
            DataSet dsSelectData = new DataSet();
            OleDbDataAdapter objDataAdapter;
            OleDbCommand objCommand;
            

            try
            {
                objDataAdapter = new OleDbDataAdapter();
                objCommand = new OleDbCommand();
                
                objCommand.CommandText = strSpname;
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Connection = OpenDataSource(ConnectionString);

                if (arrDataParameter != null && arrDataParameter.Count > 0)
                {
                    foreach (OleDbParameter sp_Param in arrDataParameter)
                    {
                        objCommand.Parameters.Add(sp_Param);
                    }
                }
                objDataAdapter.SelectCommand = objCommand;
                objDataAdapter.Fill(dsSelectData);
            }
            catch (OleDbException se)
            {
                throw se;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                objDataAdapter = null;
                CloseDataSources();
            }
            return dsSelectData;
        }

        public DataSet executeOleDbCommandTextReturnDS(string strCommandText, string ConnectionString)
        {
            DataSet dsSelectData = new DataSet();
            OleDbDataAdapter objDataAdapter;
            OleDbCommand objCommand;
            

            try
            {
                objDataAdapter = new OleDbDataAdapter();
                objCommand = new OleDbCommand();
                objCommand.CommandText = strCommandText;
                objCommand.CommandType = CommandType.Text;
                objCommand.Connection = OpenDataSource(ConnectionString);
                objDataAdapter.SelectCommand = objCommand;
                objDataAdapter.Fill(dsSelectData);
            }
            catch (OleDbException se)
            {
                throw se;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                objDataAdapter = null;
                CloseDataSources();
            }
            return dsSelectData;
        }


        public DataSet executeOdbcCommandTextReturnDS(string strCommandText, string ConnectionString)
        {
            DataSet dsSelectData = new DataSet();
            OdbcDataAdapter objOdbcDataAdapter;
            OdbcCommand objCommand;


            try
            {
                objOdbcDataAdapter = new OdbcDataAdapter();
                objCommand = new OdbcCommand();
                
                objCommand.CommandText = strCommandText;
                objCommand.CommandType = CommandType.Text;
                objCommand.Connection = OpenDataSourceOdbc(ConnectionString);
                objOdbcDataAdapter.SelectCommand = objCommand;
                objOdbcDataAdapter.Fill(dsSelectData);
                return dsSelectData;
            }
            catch (OdbcException se)
            {
                throw se;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                objOdbcDataAdapter = null;
                 CloseDataSources();
            }
            
        }

        public DataSet executeOracleCommandTextReturnDS(string strCommandText, string ConnectionString)
        {
           DataSet dsSelectData = new DataSet();
           DataSet tempDataSet;
            int index = 0;
            OracleDataAdapter objOracleDataAdapter;
            OracleCommand objCommand;
            try
            {
                string[] split = strCommandText.Split(new Char[] { ';' });
                objOracleDataAdapter = new OracleDataAdapter();
                objCommand = new OracleCommand();
                objCommand.Connection = OpenDataSourceOracle(ConnectionString);
                foreach (string comText in split)
                {
                    tempDataSet = new DataSet();
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = comText;
                    objOracleDataAdapter.SelectCommand = objCommand;
                    objOracleDataAdapter.Fill(tempDataSet);
                    dsSelectData.Tables.Add(tempDataSet.Tables[0].Copy());
                    dsSelectData.Tables[index].TableName = "Table" + index;
                    index++;
                }
                
                return dsSelectData;
            }
            catch (OracleException se)
            {
                throw se;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                objOracleDataAdapter = null;
                tempDataSet = null;
                 CloseDataSources();
            }

        }

        public DataSet executeSqlCommandTextReturnDS(string strCommandText, string ConnectionString)
        {
            DataSet dsSelectData = new DataSet();
            DataSet tempDataSet;
            int index = 0;
            SqlDataAdapter objSqlDataAdapter;
            SqlCommand objCommand;
            try
            {
                string[] split = strCommandText.Split(new Char[] { ';' });
                objSqlDataAdapter = new SqlDataAdapter();
                objCommand = new SqlCommand();
                objCommand.Connection = OpenDataSourceSql(ConnectionString);
                foreach (string comText in split)
                {
                    tempDataSet = new DataSet();
                    objCommand.CommandType = CommandType.Text;
                    objCommand.CommandText = comText;
                    objSqlDataAdapter.SelectCommand = objCommand;
                    objSqlDataAdapter.Fill(tempDataSet);
                    dsSelectData.Tables.Add(tempDataSet.Tables[0].Copy());
                    dsSelectData.Tables[index].TableName = "Table" + index;
                    index++;
                }

                return dsSelectData;
            }
            catch (SqlException se)
            {
                throw se;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                objSqlDataAdapter = null;
                tempDataSet = null;
                 CloseDataSources();
            }

        }

        #endregion

        #region public void executeSP(string strSpname, ArrayList arrDataParameter)

        /// <summary>
        /// Executes the stored procedure
        /// </summary>
        /// <param name="strSpname"></param>
        /// <param name="arrDataParameter"></param>
        public void executeSP(string strSpname, ArrayList arrDataParameter,string ConnectionString)
        {
            OleDbCommand objCommand;

            try
            {
                objCommand = new OleDbCommand();
                objCommand.CommandText = strSpname;
                
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Connection = OpenDataSource(ConnectionString);

                if (arrDataParameter != null && arrDataParameter.Count > 0)
                {
                    foreach (OleDbParameter sp_Param in arrDataParameter)
                    {
                        objCommand.Parameters.Add(sp_Param);
                    }
                }

                objCommand.ExecuteNonQuery();
            }
            catch (OleDbException se)
            {
                throw se;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                 CloseDataSources();
                objCommand = null;
            }
        }

        #endregion

        #endregion

        #region Fire SP with params, return DataReader

        /// <summary>
        /// Executes the stored procedure and returns DataReader
        /// </summary>
        /// <param name="strSpname"></param>
        /// <param name="arrDataParameter"></param>
        /// <returns></returns>
        public OleDbDataReader executeSPReturnDR(string strSpname, ArrayList arrDataParameter,string ConnectionString)
        {
            OleDbCommand objCommand;

            try
            {
                objCommand = new OleDbCommand();
                objCommand.CommandText = strSpname;
                
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.Connection = OpenDataSource(ConnectionString);

                if (arrDataParameter != null && arrDataParameter.Count > 0)
                {
                    foreach (OleDbParameter sp_Param in arrDataParameter)
                    {
                        objCommand.Parameters.Add(sp_Param);
                    }
                }
                return objCommand.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (OleDbException se)
            {
                throw se;
            }
            catch (Exception e)
            {
                throw e;
            }
            finally
            {
                 CloseDataSources();
            }
        }

        #endregion
              
        #region Read Connection String

        #region private string ReadConnectionString()

        /// <summary>
        /// Reads the connection string from config file
        /// </summary>
        /// <returns>The Connection string to the database</returns>
        private string ReadConnectionString(string ConnectionString)
        {
            try
            {
                if (_strConnectionString == null)
                {
                    _strConnectionString = ConnectionString;
                }
                return _strConnectionString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #endregion

        #region Application Settings

        #region public DataSet executeApplicationXMLReturnDS(string strFileName)

        /// <summary>
        /// Reads the App.config file for Application Settings.
        /// </summary>
        /// <param name="strFileName"></param>
        /// <returns></returns>
        public DataSet executeApplicationXMLReturnDS(string strFileName)
        {
            DataSet appDS=new DataSet();
            try
            {
                appDS.ReadXml(strFileName);
                return appDS;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        #endregion

        #endregion

        #endregion

        #region Class Constants

        public struct DBConstants
        {
            internal const string STR_CONNECTION_STRING = "CONNECTION_STRING";
            internal const string STR_RETURNVALUE_PARAM = "@RETURN_PARAM";
            internal const string STR_DATABASE = "DATABASE";
        }

        #endregion
    }

    #endregion
}

#endregion