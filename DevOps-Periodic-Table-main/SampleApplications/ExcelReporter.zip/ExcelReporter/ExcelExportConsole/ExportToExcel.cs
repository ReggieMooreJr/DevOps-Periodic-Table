﻿/*
*****************************************************************************************************
CopyRight   : UnitedHealth Group.
Date   	    :	9th June 2010
Developer By:	.Net CoP Gurgaon.
Description :	Script Builder is a comprehensive and easy to use tool to export data from any oledb
                database to excel Sheet. All the queries, worksheet names, connection settings and mail   
                settings can be configured in xml configuration file. It takes xml as command line parameter
                so, different xml files can be configured to work with the application. 
Contact:      India-UHG ITO DotNet Core Group
******************************************************************************************************
 */
#region References
using System;
using System.Collections;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics;
using System.Net;
using System.Net.Mail;
using System.Net.Mime;
using System.Reflection;
using System.Runtime.InteropServices;
using Microsoft.Office.Interop.Excel;
using DataTable=Microsoft.Office.Interop.Excel.DataTable;
using UHG.CARE.DataManager;
using System.Text;
using System.IO;
using UHG.CARE.LOGGER;
#endregion

#region namespace UHG.CARE.ExcelReporter
namespace UHG.CARE.ExcelReporter
{
    #region class GenerateReportConsole

    /// <summary>
    /// Launch an instance of Generate Report
    /// </summary>
    /// Revision History: 
    /// Author					| Ver			| Date				| Reason
    /// Sumit  			        | 5th May 2010 	| Intial Creation
    public class GenerateReportConsole
    {
       static void Main()
        {
            ExportToExcel objCreateExcelWorksheet = new ExportToExcel();
            Logger objLogger=new Logger();
            try
            {
                objCreateExcelWorksheet.GenerateReport();
                objCreateExcelWorksheet.SendMail();
                objCreateExcelWorksheet.SendMail("", false);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
                objLogger.ErrorLog(ex.Message + "\n" + ex.StackTrace);
                objCreateExcelWorksheet.SendMail(ex.Message + "\n" + ex.StackTrace, true);
            }
         }
    }
    #endregion

    #region class ExportToExcel
    public class ExportToExcel
    {
        /// <summary>  
        // Class to export the database results set to excel. 
        /// </summary>  

        #region Declarations
        private DataSet dsReportData = new DataSet();
        private int i = 1;
        private Application excelApp = new Application();
        private Workbook excelWorkbook = null;
        private Sheets excelSheets = null;
        private Worksheet excelWorksheet = null;
        private Workbooks excelWorkbooks = null;
        private Hashtable htreportSettings = null;
        private DBAccess objDataAccessLayer;
        private string excelReportFile=string.Empty; 
        Style styleHeaderRow = default(Microsoft.Office.Interop.Excel.Style);
        Style styleDataRow = default(Microsoft.Office.Interop.Excel.Style);
        private Range rngCurrentCell;
        Logger objLogger = new Logger();
        private string databaseType = string.Empty;

        private string reportDate = DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString() + "-" +
                              DateTime.Now.Year.ToString();
       #endregion

        #region Public Methods
        public void GenerateReport()
        {
           try
           {
            excelApp.DisplayAlerts = false;
            objDataAccessLayer = new DBAccess();
            htreportSettings = DataSetToArraylist(objDataAccessLayer.executeApplicationXMLReturnDS("ReportSettings.xml"));
            CreateDataSet();
            excelWorkbook = excelApp.Workbooks.Add(Environment.CurrentDirectory +"\\"+ htreportSettings["ReportTemplateFilePath"]);
            //Header Row Style
            styleHeaderRow = excelWorkbook.Styles.Add("StyleHeaderRow", Type.Missing);
            styleHeaderRow.Font.Bold = true;
            styleHeaderRow.Interior.Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.LightGray);
           //Data  Row Style
            styleDataRow = excelWorkbook.Styles.Add("StyleDataRow", Type.Missing);
            styleDataRow.HorizontalAlignment = XlHAlign.xlHAlignGeneral;
            foreach (System.Data.DataTable dt in dsReportData.Tables)
            {
                objLogger.AuditLog("Creating Worksheet " + htreportSettings["ReportName" + i].ToString() + reportDate);
                excelWorksheet = CreateWorksheets(dt.TableName);
                excelWorksheet.Name = htreportSettings["ReportName" + i].ToString() + "-" + reportDate;
                excelWorksheet.Activate();
                PopulateDatatableToExcelSheet(dt, excelWorksheet);
                i++;
            }
            ((Worksheet)this.excelApp.ActiveWorkbook.Sheets["Summary"]).Delete();
            
            excelReportFile = htreportSettings["ReportFilePath"].ToString() +
                                 htreportSettings["ReportFileName"].ToString() + "_" + reportDate + ".xls";
            objLogger.AuditLog("Saving Workbook " + htreportSettings["ReportFilePath"].ToString() + htreportSettings["ReportFileName"].ToString() +"_"+ reportDate+".xls");
            excelWorkbook.SaveAs(htreportSettings["ReportFilePath"].ToString() + htreportSettings["ReportFileName"].ToString() + "_" + reportDate + ".xls", Type.Missing, Type.Missing, Type.Missing,
                                    Type.Missing, Type.Missing, XlSaveAsAccessMode.xlNoChange,
                        Type.Missing, Type.Missing, Type.Missing, Type.Missing,
                                    Type.Missing);
            excelWorkbooks = excelApp.Workbooks;
            excelSheets = excelWorkbook.Worksheets;
            Console.WriteLine(excelReportFile + " generated successfully.");
               }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
           {
               objDataAccessLayer = null;
               ReleaseMemory();
               
           }
         }
        #endregion

        #region Private Methods

        /// <summary>
        /// This method is going to create the worksheets within the workbook. 
        /// </summary>
        /// <param name="sheetName"></param>
        private Worksheet CreateWorksheets(string sheetName)
        {
            //To View the progress in excel sheet.
            //excelApp.Visible = true;
            Worksheet sheet = (Worksheet)excelWorkbook.Worksheets.Add(Type.Missing, Type.Missing, Type.Missing, Type.Missing);
            return sheet;

        }

        /// <summary>
        /// This method is going to Populate the excel file from the underlying datatable. 
        /// </summary>
        /// <param name="dataTable"></param>
        /// <param name="excelSheet"></param>
        private void PopulateDatatableToExcelSheet(System.Data.DataTable dataTable, Worksheet excelSheet)
        {
            objLogger.AuditLog("Populating data in Worksheet " + excelSheet.Name);
            // Copy the values from a DataTable to an Excel Sheet (Column Headings Cell by cell)
            int columnIndex=0;
            foreach (System.Data.DataColumn dc in dataTable.Columns)
            {
                excelSheet.Cells[1, columnIndex + 1] =
                     dc.ColumnName;
                rngCurrentCell = (Range)excelSheet.Cells[1, columnIndex + 1];
                    rngCurrentCell.EntireColumn.AutoFit();
                    rngCurrentCell.Style = "StyleHeaderRow";
                columnIndex++;
            }
                       
            // Copy the values from a DataTable to an Excel Sheet (cell-by-cell)
            for (int col = 0; col < dataTable.Columns.Count; col++)
            {
                for (int row = 0; row < dataTable.Rows.Count; row++)
                {
                    if(dataTable.Rows[row].ItemArray[col].ToString() == "-12345")
                        excelSheet.Cells[row + 2, col + 1]="";
                    else 
                    excelSheet.Cells[row + 2, col + 1] ="'"+
                            dataTable.Rows[row].ItemArray[col];
                    rngCurrentCell = (Range)excelSheet.Cells[row + 2, col + 1];
                    rngCurrentCell.EntireColumn.AutoFit();
                    rngCurrentCell.Style = "StyleDataRow";
                    
                }
            }
           
        }

        /// <summary>
        /// This method is going to create the dataset from the underlying database. 
        /// </summary>
        private void CreateDataSet()
        {
            #region Dummy DataSet Creation Code
            /*System.Data.DataTable dt = new System.Data.DataTable("TableName For Sheet1");
            dt.Columns.Add("Sheet1_1");
            dt.Columns.Add("Sheet1_2");
            dt.Rows.Add("Value1", "Value2");

            System.Data.DataTable dt2 = new System.Data.DataTable("TableName For Sheet2");
            dt2.Columns.Add("Sheet2_1");
            dt2.Columns.Add("Sheet2_2");
            dt2.Rows.Add("Value1", "Value2");

            System.Data.DataTable dt3 = new System.Data.DataTable("TableName For Sheet3");
            dt3.Columns.Add("Sheet3_1");
            dt3.Columns.Add("Sheet3_2");
            dt3.Rows.Add("Value1", "Value2");

            dsReportData.Tables.Add(dt);
            dsReportData.Tables.Add(dt2);
            dsReportData.Tables.Add(dt3);*/
            #endregion

            try
            {
                objLogger.AuditLog("Fetching data from Database");
                GetDataSetForExcel(htreportSettings["Database"].ToString());
            }
            catch(Exception ex)
            {
                throw ex;
            }
        }

        private void GetDataSetForExcel(string databaseType)
        {
           
            if (databaseType=="Oracle")
            {
                dsReportData = objDataAccessLayer.executeOracleCommandTextReturnDS(DataSetToArraylist(htreportSettings), htreportSettings["ConnectionString"].ToString());
            }
            else if (databaseType == "Sql")
            {
                dsReportData = objDataAccessLayer.executeSqlCommandTextReturnDS(DataSetToArraylist(htreportSettings), htreportSettings["ConnectionString"].ToString());
            }
            else if (databaseType == "Odbc")
            {
                dsReportData = objDataAccessLayer.executeOdbcCommandTextReturnDS(DataSetToArraylist(htreportSettings), htreportSettings["ConnectionString"].ToString());
            }
            else if (databaseType == "OleDb")
            {
                dsReportData = objDataAccessLayer.executeOleDbCommandTextReturnDS(DataSetToArraylist(htreportSettings), htreportSettings["ConnectionString"].ToString());
            }
        }

        /// <summary>
        /// This method is used to convert dataset to arraylist
        /// </summary>
        private Hashtable DataSetToArraylist(DataSet ds)
        {
            Hashtable settingHashtable = new Hashtable();
            System.Data.DataTable dataTable = ds.Tables[0];

            // Copy the values from a DataTable to an Excel Sheet (cell-by-cell)
            for (int col = 0; col < dataTable.Columns.Count; col++)
            {
                for (int row = 0; row < dataTable.Rows.Count; row++)
                {
                   settingHashtable.Add(dataTable.Columns[col].ColumnName,dataTable.Rows[row].ItemArray[col]);
                }
            }
            return settingHashtable;
        }

        /// <summary>
        /// This method is used to create the command text
        /// </summary>
        private string DataSetToArraylist(Hashtable  ht)
        {
            StringBuilder sb=new StringBuilder();
            foreach (DictionaryEntry entry in ht)
            {
                if (entry.Key.ToString().StartsWith("ReportQuery"))
                         sb.Append(entry.Value+";");
            }
           return sb.ToString().Remove(sb.Length - 1, 1);

        }

        public void SendMail()
        {
            MailMessage mailMsg;
            MailAddress mailAddress;
            Attachment data;
            ContentDisposition disposition;
            SmtpClient smtpClient;
            NetworkCredential credentials;
                try
                {
                    if (htreportSettings["SendMail"].ToString() == "Y")
                    {
                        // To
                        mailMsg = new MailMessage();
                        mailMsg.To.Add(htreportSettings["MailTo"].ToString());

                        // From
                        mailAddress = new MailAddress(htreportSettings["MailFrom"].ToString());
                        mailMsg.From = mailAddress;

                        // Subject and Body
                        mailMsg.Subject = htreportSettings["MailSubject"].ToString();
                        mailMsg.Body = htreportSettings["MailBody"].ToString();

                        // Create  the file attachment for this e-mail message.
                        data = new Attachment(excelReportFile, MediaTypeNames.Application.Octet);
                        //Get the file path to attach.
                        excelReportFile = htreportSettings["ReportFilePath"].ToString() +
                         htreportSettings["ReportFileName"].ToString() + "_" + reportDate + ".xls";
                        // Add time stamp information for the file.
                        disposition = data.ContentDisposition;
                        disposition.CreationDate = System.IO.File.GetCreationTime(excelReportFile);
                        disposition.ModificationDate = System.IO.File.GetLastWriteTime(excelReportFile);
                        disposition.ReadDate = System.IO.File.GetLastAccessTime(excelReportFile);
                        // Add the file attachment to this e-mail message.
                        mailMsg.Attachments.Add(data);
                        // Init SmtpClient and send
                        smtpClient = new SmtpClient(htreportSettings["MailHost"].ToString());
                        objLogger.AuditLog("Sending Mail ");
                        smtpClient.Send(mailMsg);
                        Console.WriteLine("Mail Sent Successfully.");
                        objLogger.AuditLog("Mail Sent Successfully.");
                    }
                   
                }
                catch (Exception ex)
                {
                    throw ex;
                }
                finally
                {
                    
                    mailMsg = null;
                    mailAddress = null;
                    data = null;
                    disposition = null;
                    smtpClient = null;
                    credentials = null;
                }
            
        }

        public void SendMail(string message, bool isError)
        {
            MailMessage mailMsg;
            MailAddress mailAddress;
            Attachment data;
            ContentDisposition disposition;
            SmtpClient smtpClient;
            NetworkCredential credentials;
            try
            {
                if (htreportSettings["SendMail"].ToString() == "Y")
                {
                    // To
                    mailMsg = new MailMessage();
                    mailMsg.To.Add(htreportSettings["AdminMail"].ToString());

                    // From
                    mailAddress = new MailAddress(htreportSettings["MailFrom"].ToString());
                    mailMsg.From = mailAddress;

                    // Subject and Body
                    if (isError)
                    {
                        mailMsg.Subject = "Error occured while generating the report.";
                        mailMsg.Body = "This is a autogenerated mail.Following Error has ocurred in the application \n" + message;
                    }
                    else
                    {
                        mailMsg.Subject = "Report sent successfully.";
                        mailMsg.Body = "This is a autogenerated mail.";
                    }

                    // Init SmtpClient and send
                    smtpClient = new SmtpClient(htreportSettings["MailHost"].ToString());
                    objLogger.AuditLog("Sending Mail ");
                    smtpClient.Send(mailMsg);
                    Console.WriteLine("Audit/Error mail Sent Successfully.");
                    objLogger.AuditLog("Audit/Error mail Sent Successfully.");
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                mailMsg = null;
                mailAddress = null;
                data = null;
                disposition = null;
                smtpClient = null;
                credentials = null;
            }

        }
        /// <summary>
        /// This method is going to release memory
        /// </summary>
        private void ReleaseMemory()
        {
            try
            {
                objLogger.AuditLog("Releasing Memory " );
                //app.Quit(); // should give you a "Sorry, I can't find this Excel session since you killed it" Exception.
                if (excelWorkbook != null)
                {
                    excelWorkbook.Close(false, System.Reflection.Missing.Value, System.Reflection.Missing.Value);

                    excelApp.Quit();

                    Marshal.ReleaseComObject(excelWorksheet);

                    if (excelWorksheet != null)
                        Marshal.ReleaseComObject(excelWorksheet);
                    if (excelSheets != null)
                        Marshal.ReleaseComObject(excelSheets);
                    if (excelWorkbooks != null)
                        Marshal.ReleaseComObject(excelWorkbooks);
                    if (excelWorkbook != null)
                        Marshal.ReleaseComObject(excelWorkbook);
                    if (excelApp != null)
                    excelApp = null;

                    GC.GetTotalMemory(false);
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                    GC.Collect();
                    GC.GetTotalMemory(true);
                    KillAllExcels();

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }}

       private void KillAllExcels()
        {
            System.Diagnostics.Process proc = default(System.Diagnostics.Process);
            foreach (var proc2 in System.Diagnostics.Process.GetProcessesByName("EXCEL"))
            {
                proc2.Kill();
            }
        } 

        #endregion
    }
    #endregion
}
 
#endregion