/*****************************************************************************************************
CopyRight   : UnitedHealth Group.
Date   	    :	9th June 2010
Developer By:	.Net CoP Gurgaon.
Description :	Script Builder is a comprehensive and easy to use tool to export data from any oledb
                database to excel Sheet. All the queries, worksheet names, connection settings and mail   
                settings can be configured in xml configuration file. It takes xml as command line parameter
                so, different xml files can be configured to work with the application. 
Contact:      India-UHG ITO DotNet Core Group
******************************************************************************************************/
#region References 
using System;
using System.IO;
using System.Text;
#endregion

#region namespace UHG.CARE.LOGGER
namespace UHG.CARE.LOGGER
{
	//<Summary>
	// This class used to created log files
    //</Summary>
    #region class Logger
    /// <summary>
    /// Used to log messages Error and Audit messages. 
    /// </summary>
    /// Revision History: 
    /// Author					| Ver			| Date				| Reason
    /// Sumit  			        | 5th May 2010 	| Intial Creation
    public class Logger
	{
		private string sLogFormat;
		private string sErrorTime;
        private string ErrorLogFileName = "ErrorLog.txt";
        private string auditLogFileName = "AuditLog.txt";
        #region Constructor
        public Logger()
		{
			//sLogFormat used to create log files format :
			// dd/mm/yyyy hh:mm:ss AM/PM ==> Log Message
			sLogFormat = DateTime.Now.ToShortDateString().ToString()+" "+DateTime.Now.ToLongTimeString().ToString()+" ==> ";
			
			//this variable used to create log filename format "
			//for example filename : ErrorLogYYYYMMDD
			string sYear	= DateTime.Now.Year.ToString();
			string sMonth	= DateTime.Now.Month.ToString();
			string sDay	= DateTime.Now.Day.ToString();
			sErrorTime = sYear+sMonth+sDay;
            ErrorLogFileName = Environment.CurrentDirectory + "\\" + ErrorLogFileName;
            auditLogFileName = Environment.CurrentDirectory + "\\" + auditLogFileName;
        }
        #endregion 

        #region public Method
        public void ErrorLog(string sErrMsg)
		{
            StreamWriter sw = new StreamWriter(ErrorLogFileName, true);
            sw.WriteLine(sErrorTime + sLogFormat + "\n" + sErrMsg);
			sw.Flush();
			sw.Close();
        }

        public void AuditLog(string sAuditMsg)
        {
            StreamWriter sw = new StreamWriter(auditLogFileName, true);
            sw.WriteLine(sErrorTime + sLogFormat + "\n" + sAuditMsg);
            sw.Flush();
            sw.Close();
        }
        #endregion
    }
    #endregion
}
#endregion